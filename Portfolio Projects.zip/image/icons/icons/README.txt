Sagor Portfolio Skill Icons (SVG)
===================================
12 standalone SVG icons for your skills section.
All icons have transparent backgrounds (no background rectangle behind the icon unless part of the logo itself).

Files:
- wordpress.svg
- elementor.svg
- woocommerce.svg
- custom-plugin.svg
- git.svg
- figma.svg
- html5.svg
- css3.svg
- javascript.svg
- tailwind-css.svg
- digital-marketing.svg
- seo-optimization.svg

Usage in HTML:
<img src="image/icons/wordpress.svg" alt="WordPress" width="48" height="48">

Note: These are clean, custom SVG illustrations. Some are simplified representations, not official trademark asset downloads.
