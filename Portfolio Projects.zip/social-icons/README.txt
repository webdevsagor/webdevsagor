SAGOR FOOTER SOCIAL ICONS

Included SVG files:
- facebook.svg
- whatsapp.svg
- linkedin.svg
- x.svg
- fiverr.svg
- upwork.svg

The SVGs have transparent backgrounds and are designed to sit inside your own glowing, rounded social-link boxes.

HTML example:
<div class="social-links">
  <a class="social-link" href="#" aria-label="Facebook"><img src="image/facebook.svg" alt=""></a>
  <a class="social-link" href="#" aria-label="WhatsApp"><img src="image/whatsapp.svg" alt=""></a>
  <a class="social-link" href="#" aria-label="LinkedIn"><img src="image/linkedin.svg" alt=""></a>
  <a class="social-link" href="#" aria-label="X"><img src="image/x.svg" alt=""></a>
  <a class="social-link" href="#" aria-label="Fiverr"><img src="image/fiverr.svg" alt=""></a>
  <a class="social-link" href="#" aria-label="Upwork"><img src="image/upwork.svg" alt=""></a>
</div>

CSS example:
.social-links {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}
.social-link {
  width: 42px;
  height: 42px;
  display: flex;
  justify-content: center;
  align-items: center;
  border: 1px solid #14548a;
  border-radius: 10px;
  background: rgba(15, 45, 75, 0.35);
  box-shadow: 0 0 10px rgba(0, 153, 255, 0.12), inset 0 0 8px rgba(0, 153, 255, 0.06);
  transition: 0.25s ease;
}
.social-link img {
  width: 23px;
  height: 23px;
  display: block;
}
.social-link:hover {
  border-color: #39baff;
  box-shadow: 0 0 14px rgba(0, 153, 255, 0.45);
  transform: translateY(-2px);
}

Update href="#" to your actual social profile URLs. If your folders are different, update the img src paths.
